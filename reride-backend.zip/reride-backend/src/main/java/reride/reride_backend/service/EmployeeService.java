package reride.reride_backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import reride.reride_backend.component.JwtUtil;
import reride.reride_backend.dto.EmployeeDTO;
import reride.reride_backend.entity.Branch;
import reride.reride_backend.entity.Employee;
import reride.reride_backend.enums.Role;
import reride.reride_backend.repository.BranchRepo;
import reride.reride_backend.repository.EmployeeRepo;

import java.nio.file.AccessDeniedException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepo employeeRepo;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    JwtUtil jwtUtil;

    @Autowired
    BranchRepo branchRepo;


    public Employee addEmployee(String authHeader, Employee employeeData) throws AccessDeniedException {
        String token = authHeader.substring(7);
        Long requesterId = jwtUtil.extractUserId(token);
        String requesterRole = jwtUtil.extractUserRole(token);

        // Validate role-based permissions
        if (employeeRepo.findByEmployeeEmail(employeeData.getEmployeeEmail()).isPresent()) {
            throw new RuntimeException("Employee already exists with this email");
        }

        // Fetch requester info
        Employee requester = employeeRepo.findById(requesterId)
                .orElseThrow(() -> new RuntimeException("Requester not found"));

        Branch branch = null;

        // --- Role-based restrictions ---
        if ("SUPER_ADMIN".equalsIgnoreCase(requesterRole)) {
            // SUPER_ADMIN can only add ADMINs (not staff)
            if (employeeData.getEmployeeRole() != Role.ADMIN) {
                throw new AccessDeniedException("SUPER_ADMIN can only add ADMIN employees.");
            }

            if (employeeData.getBranch() == null || employeeData.getBranch().getBranchId() == null) {
                throw new IllegalArgumentException("Branch information is required for ADMIN.");
            }

            branch = branchRepo.findById(employeeData.getBranch().getBranchId())
                    .orElseThrow(() -> new RuntimeException("Branch not found with ID: " + employeeData.getBranch().getBranchId()));

        } else if ("ADMIN".equalsIgnoreCase(requesterRole)) {
            // ADMIN can only add STAFF, and only to their own branch
            if (employeeData.getEmployeeRole() != Role.STAFF) {
                throw new AccessDeniedException("ADMIN can only add STAFF.");
            }

            if (requester.getBranch() == null) {
                throw new IllegalArgumentException("Admin must be assigned to a branch.");
            }

            // Force-assign staff to the admin’s branch
            branch = requester.getBranch();

        } else {
            throw new AccessDeniedException("Access denied: Only SUPER_ADMIN or ADMIN can add employees.");
        }

        // Save new employee
        Employee employee = new Employee();
        employee.setEmployeeName(employeeData.getEmployeeName());
        employee.setEmployeeEmail(employeeData.getEmployeeEmail());
        employee.setEmployeePhNo(employeeData.getEmployeePhNo());
        employee.setEmployeeRole(employeeData.getEmployeeRole());
        employee.setEmployeePassword(passwordEncoder.encode(employeeData.getEmployeePassword()));
        employee.setBranch(branch);
        employee.setAddedById(requester);

        return employeeRepo.save(employee);
    }

    public EmployeeDTO employeeLoginService(Employee employeeFormData) {
//        System.out.println(employeeFormData.getEmployeeEmail());
        return employeeRepo.findByEmployeeEmail(employeeFormData.getEmployeeEmail())
                .filter(employee -> passwordEncoder.matches(employeeFormData.getEmployeePassword(), employee.getEmployeePassword()))
                .map(employee -> {
                    String token = jwtUtil.generateToken(employee.getEmployeeEmail(), employee.getEmployeeId(),employee.getEmployeeRole());
                    return new EmployeeDTO(
                            token,
                            employee.getEmployeeId(),
                            employee.getEmployeeName(),
                            employee.getEmployeePhNo(),
                            employee.getEmployeeEmail(),
                            employee.getEmployeeRole(),
                            employee.getAddedById()
                    );
                })
                .orElseThrow(() -> new RuntimeException("Employee Login Failed"));
    }

    public List<EmployeeDTO> getEmployeeService(String authHeader) throws AccessDeniedException {
        String jwt=authHeader.substring(7);
        Long employeeId=jwtUtil.extractUserId(jwt);
        String employeeRole=jwtUtil.extractUserRole(jwt);
        System.out.println("employeeId: "+employeeId +" employeeRole: "+employeeRole);
        if (!("SUPER_ADMIN".equalsIgnoreCase(employeeRole) || "ADMIN".equalsIgnoreCase(employeeRole))) {
            throw new AccessDeniedException("Access denied: Only SUPER_ADMIN and ADMIN can view employee list.");
        }
        return employeeRepo.findAll().stream()
                .map(employee -> new EmployeeDTO(
                        null,
                        employee.getEmployeeId(),
                        employee.getEmployeeName(),
                        employee.getEmployeePhNo(),
                        employee.getEmployeeEmail(),
                        employee.getEmployeeRole(),
                        employee.getAddedById()
                )).toList();
    }

    public Optional<Employee> getEmployeeByIdService(String authHeader, Long employeeId) throws AccessDeniedException {
        String jwt=authHeader.substring(7);
        Long employeeIdByToken=jwtUtil.extractUserId(jwt);
        String employeeRole=jwtUtil.extractUserRole(jwt);
        System.out.println("employeeId: "+employeeId +" employeeRole: "+employeeRole);
        Employee employee=employeeRepo.findById(employeeIdByToken).orElseThrow(() -> new RuntimeException("Employee Doesn't exist"));
        if (!("SUPER_ADMIN".equalsIgnoreCase(employeeRole) || "ADMIN".equalsIgnoreCase(employeeRole))) {
            throw new AccessDeniedException("Access denied: Only SUPER_ADMIN and ADMIN can view employee list.");
        }
        return employeeRepo.findById(employeeId);
    }

    public EmployeeDTO getEmployeeDetails(String authHeader) {
        String jwt=authHeader.substring(7);
        Long employeeId=jwtUtil.extractUserId(jwt);
        String employeeRole=jwtUtil.extractUserRole(jwt);
        System.out.println("employeeId: "+employeeId +" employeeRole: "+employeeRole);
        Employee employee = employeeRepo.findById(employeeId)
                .orElseThrow(() -> new UsernameNotFoundException("user not found"));

        EmployeeDTO dto = new EmployeeDTO(
                null, // token
                employee.getEmployeeId(),
                employee.getEmployeeName(),
                employee.getEmployeePhNo(),
                employee.getEmployeeEmail(),
                employee.getEmployeeRole(),
                null
        );
        return dto;
    }

    public Employee updateEmployeeService(String authHeader, Long employeeId, Employee updatedData)
            throws AccessDeniedException {
        String token = authHeader.substring(7);
        Long requesterId = jwtUtil.extractUserId(token);
        String requesterRole = jwtUtil.extractUserRole(token);

        Employee requester = employeeRepo.findById(requesterId)
                .orElseThrow(() -> new RuntimeException("Requester not found"));

        Employee existing = employeeRepo.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found with ID: " + employeeId));

        // --- Role-based logic ---
        if ("SUPER_ADMIN".equalsIgnoreCase(requesterRole)) {
            if (existing.getEmployeeRole() != Role.ADMIN) {
                throw new AccessDeniedException("SUPER_ADMIN can only update ADMIN employees.");
            }
        } else if ("ADMIN".equalsIgnoreCase(requesterRole)) {
            if (existing.getEmployeeRole() != Role.STAFF) {
                throw new AccessDeniedException("ADMIN can only update STAFF employees.");
            }
            if (!existing.getBranch().getBranchId().equals(requester.getBranch().getBranchId())) {
                throw new AccessDeniedException("ADMIN can only update STAFF within their own branch.");
            }
        } else {
            throw new AccessDeniedException("Access denied: Invalid role for updating employee.");
        }

        // Apply updates
        if (updatedData.getEmployeeName() != null)
            existing.setEmployeeName(updatedData.getEmployeeName());
        if (updatedData.getEmployeePhNo() != null)
            existing.setEmployeePhNo(updatedData.getEmployeePhNo());
        if (updatedData.getEmployeeEmail() != null)
            existing.setEmployeeEmail(updatedData.getEmployeeEmail());
        if (updatedData.getEmployeePassword() != null && !updatedData.getEmployeePassword().isBlank())
            existing.setEmployeePassword(passwordEncoder.encode(updatedData.getEmployeePassword()));

        return employeeRepo.save(existing);
    }

    public void deleteEmployeeService(String authHeader, Long employeeId) throws AccessDeniedException {
        String token = authHeader.substring(7);
        Long requesterId = jwtUtil.extractUserId(token);
        String requesterRole = jwtUtil.extractUserRole(token);

        Employee requester = employeeRepo.findById(requesterId)
                .orElseThrow(() -> new RuntimeException("Requester not found"));

        Employee target = employeeRepo.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found with ID: " + employeeId));

        // --- Role-based logic ---
        if ("SUPER_ADMIN".equalsIgnoreCase(requesterRole)) {
            if (target.getEmployeeRole() != Role.ADMIN) {
                throw new AccessDeniedException("SUPER_ADMIN can only delete ADMIN employees.");
            }
        } else if ("ADMIN".equalsIgnoreCase(requesterRole)) {
            if (target.getEmployeeRole() != Role.STAFF) {
                throw new AccessDeniedException("ADMIN can only delete STAFF employees.");
            }
            if (!target.getBranch().getBranchId().equals(requester.getBranch().getBranchId())) {
                throw new AccessDeniedException("ADMIN can only delete STAFF within their own branch.");
            }
        } else {
            throw new AccessDeniedException("Access denied: Invalid role for deleting employee.");
        }

        employeeRepo.delete(target);
    }
}
