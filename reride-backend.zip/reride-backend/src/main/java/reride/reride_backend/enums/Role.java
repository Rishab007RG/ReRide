package reride.reride_backend.enums;

public enum Role {
    USER,
    SUPER_ADMIN,
    ADMIN,
    STAFF,
}
