package reride.reride_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RerideBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RerideBackendApplication.class, args);
	}

}
